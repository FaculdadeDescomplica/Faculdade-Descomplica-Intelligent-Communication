from http.server import BaseHTTPRequestHandler, HTTPServer
import json

# Simulando um banco de dados de usuários
USERS = {
    'admin': {'role': 'admin', 'password': 'admin123'},
    'user': {'role': 'user', 'password': 'user123'}
}

# Função para verificar se o usuário é administrador
def is_admin(username):
    user = USERS.get(username)
    return user and user['role'] == 'admin'

class MyHandler(BaseHTTPRequestHandler):
    # Rota GET padrão
    def do_GET(self):
        if self.path == '/':
            self._send_response(200, {'message': 'Bem-vindo à página inicial!'})

        elif self.path == '/admin':
            username = self.headers.get('Username')  # Simulação de autenticação
            if username and is_admin(username):
                self._send_response(200, {'message': 'Bem-vindo à página administrativa!'})
            else:
                self._send_response(403, {'error': 'Acesso negado. Somente administradores.'})

        else:
            self._send_response(404, {'error': 'Rota não encontrada'})

    # Método para enviar respostas
    def _send_response(self, status_code, content):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(content).encode('utf-8'))

# Configurando o servidor
def run(server_class=HTTPServer, handler_class=MyHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Servidor rodando na porta {port}')
    httpd.serve_forever()

if __name__ == '__main__':
    run()