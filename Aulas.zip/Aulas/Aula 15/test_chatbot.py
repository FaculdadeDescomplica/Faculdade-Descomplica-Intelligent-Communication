import unittest
from chatbot import Chatbot

class TestChatbot(unittest.TestCase):
    def setUp(self):
        self.chatbot = Chatbot()

    def test_response_known_question(self):
        self.assertEqual(self.chatbot.get_response("Olá"), "Olá! Como posso ajudar você hoje?")
        self.assertEqual(self.chatbot.get_response("Qual é o seu nome?"), "Eu sou um chatbot simples.")

    def test_response_unknown_question(self):
        self.assertEqual(self.chatbot.get_response("Pergunta desconhecida"), "Desculpe, não entendi sua pergunta.")

if __name__ == "__main__":
    unittest.main()
