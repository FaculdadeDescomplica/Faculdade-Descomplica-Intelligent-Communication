import requests

def get_weather(city, api_key):
    # URL da API do OpenWeatherMap
    # https://home.openweathermap.org/
    url = f"http://api.openweathermap.org/data/2.5/weather?q={cidade}&appid={API_KEY}&units=metric"

    # Fazendo a requisição para a API
    response = requests.get(url)

    # Verificando se a requisição foi bem-sucedida
    if response.status_code == 200:
        data = response.json()
        # Extraindo informações relevantes
        weather = data['weather'][0]['description']
        temperature = data['main']['temp']
        humidity = data['main']['humidity']

        print(f"Clima em {city}: {weather}")
        print(f"Temperatura: {temperature}°C")
        print(f"Umidade: {humidity}%")
    else:
        print(f"Erro ao obter dados: {response.status_code}")

if __name__ == "__main__":
    # Substitua pela sua chave da API
    API_KEY = "8979ac26017072f53829b6cc358348d3"
    cidade = input("Digite o nome da cidade: ")
    get_weather(cidade, API_KEY)