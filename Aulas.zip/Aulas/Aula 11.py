import http.server
import json
import ssl
from urllib.parse import urlparse
import requests
from base64 import b64decode
from http import HTTPStatus

# Configurações da API
GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY'  # Substitua pela sua chave da API

# Classe para gerenciar a API
class MyRequestHandler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path == '/protected':
            if self.authenticate():
                self.send_response(HTTPStatus.OK)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                response = {'message': 'Protected content'}
                self.wfile.write(json.dumps(response).encode())
            else:
                self.send_response(HTTPStatus.UNAUTHORIZED)
                self.end_headers()
                response = {'message': 'Unauthorized'}
                self.wfile.write(json.dumps(response).encode())
        else:
            self.send_response(HTTPStatus.NOT_FOUND)
            self.end_headers()

    def do_POST(self):
        if self.path == '/chat':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)

            user_message = data.get('message')
            bot_response = self.get_google_ai_response(user_message)

            self.send_response(HTTPStatus.OK)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'response': bot_response}).encode())
        else:
            self.send_response(HTTPStatus.NOT_FOUND)
            self.end_headers()

    def authenticate(self):
        auth_header = self.headers.get('Authorization')
        if auth_header:
            try:
                auth_type, credentials = auth_header.split()
                if auth_type.lower() == 'basic':
                    decoded_credentials = b64decode(credentials).decode('utf-8')
                    username, password = decoded_credentials.split(':')
                    return username == "user1" and password == "password1"
            except Exception:
                return False
        return False

    def get_google_ai_response(self, user_message):
        url = 'https://google.generativeai.googleapis.com/v1beta2/chat.completions:generate'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {GOOGLE_API_KEY}'
        }
        body = {
            'messages': [{'role': 'user', 'content': user_message}],
            'model': 'gemini-1.5-pro-latest'  # Altere conforme necessário
        }

        try:
            response = requests.post(url, headers=headers, json=body)
            response.raise_for_status()  # Lança um erro para respostas de erro
            return response.json().get('choices', [{}])[0].get('message', {}).get('content', 'Sem resposta')
        except requests.RequestException as e:
            return f'Erro ao se comunicar com a API do Google: {str(e)}'

# Função para iniciar o servidor
def run(server_class=http.server.HTTPServer, handler_class=MyRequestHandler):
    server_address = ('', 8080)
    httpd = server_class(server_address, handler_class)

    # Configuração de SSL
    httpd.socket = ssl.wrap_socket(httpd.socket,
                                    keyfile='path/to/your/server-key.pem',  # Insira o caminho para o seu arquivo de chave privada
                                    certfile='path/to/your/server-cert.pem',  # Insira o caminho para o seu certificado
                                    server_side=True)

    print('Starting server on https://localhost:8080...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
