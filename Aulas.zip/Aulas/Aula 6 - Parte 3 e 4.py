import pandas as pd
import numpy as np

# Definindo uma semente para reprodutibilidade
np.random.seed(42)

# Simulando dados
n = 100
nomes = ["Alice", "Bob", "Charlie", "David", "Eva"]
dados = {
    "id": range(1, n + 1),
    "nome": np.random.choice(nomes, n),
    "idade": np.random.randint(22, 60, n),
    "salario": np.round(np.random.uniform(30000, 120000, n), 2),
    "departamento": np.random.choice(["Vendas", "TI", "RH", "Financeiro"], n),
}

# Criando um DataFrame
df = pd.DataFrame(dados)

# Introduzindo alguns valores nulos e duplicados para simulação
df.loc[5, 'salario'] = np.nan  # Introduzindo um valor nulo
df = pd.concat([df, df.iloc[[3]]])  # Usando pd.concat para adicionar uma duplicata

# Exibindo os dados simulados
print("Dados Simulados:")
print(df.head())

# Tratamento e Limpeza de Dados

# 1. Verificar dados nulos
print("\nVerificando valores nulos:")
print(df.isnull().sum())

# 2. Preencher valores nulos de maneira segura
df['salario'] = df['salario'].fillna(df['salario'].mean())

# 3. Remover duplicatas
df.drop_duplicates(inplace=True)

# 4. Verificar dados após limpeza
print("\nDados após tratamento:")
print(df.info())

# 5. Análise simples
media_salario_por_departamento = df.groupby("departamento")["salario"].mean()
print("\nMédia de Salário por Departamento:")
print(media_salario_por_departamento)

# 6. Filtrando dados
funcionarios_acima_de_50k = df[df['salario'] > 50000]
print("\nFuncionários com salário acima de 50k:")
print(funcionarios_acima_de_50k)
