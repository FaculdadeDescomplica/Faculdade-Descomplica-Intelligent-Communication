import sqlite3

# Conectar ao banco de dados (ou criar um novo se não existir)
conn = sqlite3.connect('exemplo.db')

# Criar um cursor para executar comandos SQL
cursor = conn.cursor()

# Criar uma tabela
cursor.execute('''
CREATE TABLE IF NOT EXISTS pessoas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL
)
''')

# Inserir dados na tabela
cursor.execute('INSERT INTO pessoas (nome, idade) VALUES (?, ?)', ('Alice', 30))
cursor.execute('INSERT INTO pessoas (nome, idade) VALUES (?, ?)', ('Bob', 25))

# Salvar (commit) as mudanças
conn.commit()

# Consultar dados
cursor.execute('SELECT * FROM pessoas')
rows = cursor.fetchall()

# Exibir os dados
for row in rows:
    print(row)

# Fechar a conexão
conn.close()
