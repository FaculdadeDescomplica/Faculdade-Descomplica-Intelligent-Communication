import sys
import google.generativeai as genai
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QLineEdit, QPushButton, QVBoxLayout, QWidget

# Configurar a API Key do Google AI
genai.configure(api_key="AIzaSyBj1-A7It86V1raUZoVLEIIwa9DVHoRVRo")

# Inicializar o modelo Generative AI
model = genai.GenerativeModel("gemini-1.5-pro-latest")
chat = model.start_chat(history=[])


# Definição da interface gráfica usando PyQt5
class ChatbotApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Chatbot com Google AI')
        self.setGeometry(100, 100, 500, 400)

        # Layout da interface
        layout = QVBoxLayout()

        # Caixa de texto para exibir o chat
        self.chat_box = QTextEdit(self)
        self.chat_box.setReadOnly(True)
        layout.addWidget(self.chat_box)

        # Entrada de texto para a pergunta do usuário
        self.input_box = QLineEdit(self)
        layout.addWidget(self.input_box)

        # Botão de enviar
        self.send_button = QPushButton('Enviar', self)
        self.send_button.clicked.connect(self.enviar_pergunta)
        layout.addWidget(self.send_button)

        # Widget central para o layout
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    # Função para enviar a pergunta
    def enviar_pergunta(self):
        pergunta_usuario = self.input_box.text()
        if pergunta_usuario.lower() == 'fim':
            self.close()
        else:
            # Enviar pergunta para o modelo do Google AI
            response = chat.send_message(pergunta_usuario)
            resposta_texto = response.text  # Pegar a resposta do modelo

            # Exibir a pergunta e resposta na interface
            self.chat_box.append("Você: " + pergunta_usuario)
            self.chat_box.append("Chatbot: " + resposta_texto)

            # Limpar o campo de entrada
            self.input_box.clear()


# Função principal para rodar o aplicativo
def main():
    app = QApplication(sys.argv)
    chatbot = ChatbotApp()
    chatbot.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
