# augmented_reality.py

import pygame
import sys

# Inicialização do Pygame
pygame.init()

# Configurações da tela
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Realidade Aumentada Simples")

# Cores
black = (0, 0, 0)
red = (255, 0, 0)

# Posição inicial do círculo
circle_x = screen_width // 2
circle_y = screen_height // 2
circle_radius = 30

# Loop principal
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Movendo o círculo
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        circle_x -= 5
    if keys[pygame.K_RIGHT]:
        circle_x += 5
    if keys[pygame.K_UP]:
        circle_y -= 5
    if keys[pygame.K_DOWN]:
        circle_y += 5

    # Preencher a tela com preto
    screen.fill(black)

    # Desenhar o círculo
    pygame.draw.circle(screen, red, (circle_x, circle_y), circle_radius)

    # Atualizar a tela
    pygame.display.flip()
