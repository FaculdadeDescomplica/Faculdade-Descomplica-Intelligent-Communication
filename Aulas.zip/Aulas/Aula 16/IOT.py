# iot_sensor.py

import random
import time

def read_temperature():
    """Simula a leitura de um sensor de temperatura."""
    return round(random.uniform(15.0, 30.0), 2)

if __name__ == "__main__":
    print("Iniciando a coleta de dados do sensor de temperatura...")
    try:
        while True:
            temperature = read_temperature()
            print(f"Temperatura atual: {temperature} °C")
            time.sleep(2)  # Espera 2 segundos antes da próxima leitura
    except KeyboardInterrupt:
        print("Coleta de dados interrompida.")
