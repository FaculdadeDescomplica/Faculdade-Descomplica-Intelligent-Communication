import http.server
import json
import google.generativeai as genai

# Configure sua chave da API
genai.configure(api_key="AIzaSyBj1-A7It86V1raUZoVLEIIwa9DVHoRVRo")
model = genai.GenerativeModel("gemini-1.5-pro-latest")

class Chatbot:
    def get_response(self, user_input):
        chat = model.start_chat(history=[])
        response = chat.send_message(user_input)
        return response.text

class MyRequestHandler(http.server.BaseHTTPRequestHandler):
    chatbot = Chatbot()

    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(self.render_html().encode())
        elif self.path == '/api/message':
            self.send_response(405)
            self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/api/message':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            user_input = json.loads(post_data).get('message', '')
            response_message = self.chatbot.get_response(user_input)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {'response': response_message}
            self.wfile.write(json.dumps(response).encode())
        else:
            self.send_response(404)
            self.end_headers()

    def render_html(self):
        return """
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
            <title>Chatbot com Google Generative AI</title>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f8f9fa; }
                #chat-container { max-width: 500px; margin: auto; margin-top: 50px; }
                #messages { border: 1px solid #ccc; padding: 10px; height: 300px; overflow-y: scroll; background-color: #fff; }
                .message { margin: 5px; }
                .user { text-align: right; }
                .chatbot { text-align: left; }
            </style>
        </head>
        <body>
            <div id="chat-container" class="card">
                <div class="card-header">
                    <h5>Chatbot</h5>
                </div>
                <div id="messages" class="card-body"></div>
                <div class="card-footer">
                    <input type="text" id="user-input" class="form-control" placeholder="Digite sua mensagem..."/>
                    <button class="btn btn-primary mt-2" onclick="sendMessage()">Enviar</button>
                </div>
            </div>
            <script>
                function sendMessage() {
                    const userInput = document.getElementById('user-input').value;
                    if (userInput === "") return;
                    document.getElementById('messages').innerHTML += "<div class='message user'><strong>Você:</strong> " + userInput + "</div>";
                    document.getElementById('user-input').value = '';

                    fetch('/api/message', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ message: userInput })
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Erro na resposta da API: ' + response.status);
                        }
                        return response.json();
                    })
                    .then(data => {
                        document.getElementById('messages').innerHTML += "<div class='message chatbot'><strong>Chatbot:</strong> " + data.response + "</div>";
                        document.getElementById('messages').scrollTop = document.getElementById('messages').scrollHeight;
                    })
                    .catch(error => {
                        document.getElementById('messages').innerHTML += "<div class='message chatbot text-danger'>Erro: " + error.message + "</div>";
                    });
                }
            </script>
        </body>
        </html>
        """

def run(server_class=http.server.HTTPServer, handler_class=MyRequestHandler):
    server_address = ('', 8080)
    httpd = server_class(server_address, handler_class)
    print('Iniciando o servidor na porta 8080...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
