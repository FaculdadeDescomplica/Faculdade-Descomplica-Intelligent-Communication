import sys
import sqlite3
import hashlib
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget, QMessageBox

# Conectar ao banco de dados SQLite
conn = sqlite3.connect('usuarios.db')
cursor = conn.cursor()

# Criar tabela de usuários
cursor.execute('''
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    senha TEXT NOT NULL,
    preferencia TEXT
)
''')
conn.commit()


# Função para criptografar a senha (usando SHA256)
def criptografar_senha(senha):
    return hashlib.sha256(senha.encode()).hexdigest()


# Função para registrar um novo usuário
def registrar_usuario(nome, email, senha, preferencia):
    senha_criptografada = criptografar_senha(senha)

    try:
        cursor.execute('''
        INSERT INTO usuarios (nome, email, senha, preferencia)
        VALUES (?, ?, ?, ?)
        ''', (nome, email, senha_criptografada, preferencia))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


# Função para realizar login de usuário
def login_usuario(email, senha):
    senha_criptografada = criptografar_senha(senha)
    cursor.execute('''
    SELECT * FROM usuarios WHERE email = ? AND senha = ?
    ''', (email, senha_criptografada))
    usuario = cursor.fetchone()
    return usuario


# Função para editar o perfil do usuário
def editar_perfil(usuario_id, novo_nome=None, nova_preferencia=None):
    if novo_nome:
        cursor.execute('UPDATE usuarios SET nome = ? WHERE id = ?', (novo_nome, usuario_id))
    if nova_preferencia:
        cursor.execute('UPDATE usuarios SET preferencia = ? WHERE id = ?', (nova_preferencia, usuario_id))
    conn.commit()


# Função para personalizar a experiência do usuário
def personalizar_experiencia(usuario):
    preferencia = usuario[4]  # Posição 4 é onde a preferência está armazenada
    if preferencia:
        return f"Olá {usuario[1]}, você gosta de {preferencia}. Aqui estão sugestões personalizadas!"
    else:
        return f"Olá {usuario[1]}, você ainda não configurou suas preferências."


# Classe para a janela principal do PyQt5
class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.usuario_logado = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Sistema de Usuários com PyQt5')
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        self.label = QLabel("Bem-vindo ao sistema de usuários", self)
        layout.addWidget(self.label)

        self.input_email = QLineEdit(self)
        self.input_email.setPlaceholderText("Email")
        layout.addWidget(self.input_email)

        self.input_senha = QLineEdit(self)
        self.input_senha.setPlaceholderText("Senha")
        self.input_senha.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.input_senha)

        self.btn_login = QPushButton('Login', self)
        self.btn_login.clicked.connect(self.fazer_login)
        layout.addWidget(self.btn_login)

        self.btn_registrar = QPushButton('Registrar', self)
        self.btn_registrar.clicked.connect(self.registrar)
        layout.addWidget(self.btn_registrar)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def fazer_login(self):
        email = self.input_email.text()
        senha = self.input_senha.text()

        usuario = login_usuario(email, senha)
        if usuario:
            self.usuario_logado = usuario
            self.label.setText(f"Bem-vindo, {usuario[1]}!")
            self.abrir_tela_perfil()
        else:
            QMessageBox.warning(self, "Erro", "Email ou senha incorretos.")

    def registrar(self):
        nome = self.input_email.text()
        email = self.input_email.text()
        senha = self.input_senha.text()
        preferencia = 'livros'  # Exemplo de preferência inicial

        if registrar_usuario(nome, email, senha, preferencia):
            QMessageBox.information(self, "Sucesso", "Usuário registrado com sucesso!")
        else:
            QMessageBox.warning(self, "Erro", "Erro ao registrar o usuário. O email já está registrado.")

    def abrir_tela_perfil(self):
        self.input_email.hide()
        self.input_senha.hide()
        self.btn_login.hide()
        self.btn_registrar.hide()

        self.label.setText(f"Olá {self.usuario_logado[1]}, você está logado!")

        self.btn_editar_perfil = QPushButton('Editar Perfil', self)
        self.btn_editar_perfil.clicked.connect(self.editar_perfil)
        self.centralWidget().layout().addWidget(self.btn_editar_perfil)

        self.btn_personalizar = QPushButton('Personalizar Experiência', self)
        self.btn_personalizar.clicked.connect(self.personalizar_experiencia)
        self.centralWidget().layout().addWidget(self.btn_personalizar)

    def editar_perfil(self):
        novo_nome, ok = QInputDialog.getText(self, 'Editar Nome', 'Digite seu novo nome:')
        nova_preferencia, ok = QInputDialog.getText(self, 'Editar Preferência', 'Digite sua nova preferência:')

        editar_perfil(self.usuario_logado[0], novo_nome=novo_nome, nova_preferencia=nova_preferencia)
        QMessageBox.information(self, "Sucesso", "Perfil atualizado com sucesso!")

    def personalizar_experiencia(self):
        mensagem = personalizar_experiencia(self.usuario_logado)
        QMessageBox.information(self, "Personalização", mensagem)


# Executar a aplicação
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    ex.show()
    sys.exit(app.exec_())
